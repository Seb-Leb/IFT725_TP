from ift725.classifiers.linear_classifier import *
